<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réception de votre Passeport Lefri9i</title>
</head>
<body>
<div >

<p >Bonjour {{$name}}   </p>
<p >Nous vous informons que votre Passeport Lefri9i N° (@php echo str_pad($nsponso,5,0,STR_PAD_LEFT)  @endphp) est disponible dans votre boutique d’inscription et que vous pouvez le récupérer des aujourd’hui. </p>

<p>#Club_Africain</p>

</div>
</body>
</html>