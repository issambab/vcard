<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChaabhaSponsorha</title>
</head>
<body>
	<div style="text-align: right;">

<p>
السلام جمعية،
</p><p>
لقد ألغينا طلبك لأنه لا يفي بأحد هذه المعايير:
</p><p>
- إيصال الحوالة أو الدفع غير صحيح أو غير مقروء
</p><p>
- إيصال الحوالة أو السداد مستخدم
</p><p>
- الاسم و اللقب على القميص لا يتطابقان مع المعايير المفروضة على صفحة فيسبوك ChaabhaSponsorha
</p><p>
- المبلغ لا يتوافق مع ترتيب الأسماء المطلوبة
</p><p>
#شعبها_سبنصورها #الافريقي_تعيش
</p>

</div>
</body>
</html>