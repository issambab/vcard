<html>
    <head>

    </head>
    <body>
    <img src="{{asset('img/annonce.jpg')}}" alt="" style="width:100%;text-align: center;" />
    </body>
	<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-3YY0NHTT59');
</script>
</html>



