<!-- partial:partials/_footer.html -->
<footer class="footer">
            <div class="container-fluid clearfix">
              <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">copyright © 2021 Atelier216. All rights reserved.</span>
              </div>
</footer>
<!-- partial -->