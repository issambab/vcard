

<?php $__env->startSection('cssSup'); ?>
    <style >
        .btn-pos{
            position: absolute;
            right: 20px;
            top: 20px;
        }
        .btn-pos-dn{
            position: absolute;
            right: 80px;
            top: 20px;
        }
        .active{
          background-color :#01072f !important
        }
        .error{
          background-color: #fce4e4;
          border: 1px solid #cc0033;
          outline: none;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
      
        <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Information sur le client</h4>
                
                      <div class="form-group">
                        <label for="exampleInputName1"> Nom & Prénom </label>
                        <input type="text" class="form-control"  placeholder="Nom & Prénom" value="<?php echo e($client->name); ?>" id="name" name="name">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputEmail3">Email </label>
                        <input type="text" class="form-control" placeholder="Email" id="email" value="<?php echo e($client->email); ?>" name="email">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputPhone">Téléphone</label>
                        <input type="text" class="form-control"  placeholder="Téléphone" id="phone" value="<?php echo e($client->phone); ?>"   name="phone">
                      </div>
                                      
                  </div>
                </div>
              </div>
        </div>
<div class="row">

        <div class="col-md-12 grid-margin stretch-card">

                <div class="card">
            
     
                  <div class="card-body b1" >
                    <h4 class="card-title">place Reserver sur le t-shirt </h4>
                  <!--  <p class="card-description"> Basic form elements </p>-->
                    <div >

                    

                    <div class="form-group row">
                      <div class="col-12">
                        <div class="row">
                          
                            <div class="col-4">Text</div>
                            <div class="col-4">Zone</div>
                            <div class="col-4">Num</div>

                          </div>
                         </div>
                    </div>
                      
                    <div class="form-group">
	                     <div class="col-12">

		                    <div  class="row" >
		                    	 <?php $__currentLoopData = $produit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produits): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                    	    <div class="col-4"> <?php echo e($produits->text_name); ?> </div>
		                            <div class="col-4"><?php echo e($produits->zone); ?>     </div>
		                            <div class="col-4"> <?php echo e($produits->number); ?>  </div>    
		                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                   </div>

		                  </div>    
                    </div>

                    </div>
                    </div>
                </div>
         </div> 
        </div >
        <div class="row">
         <div class="col-md-12 grid-margin stretch-card">
                <div class="card ">
          
       
                  <div class="card-body">
                    <h4 class="card-title">Preuve de paiement</h4>
                  <!--  <p class="card-description"> Basic form elements </p>-->
                    <div >
                           
                      <div class="form-group row">
                          <div class="col-12">
                            <div class="row">
                              
                                <div class="col-4">N Ref</div>
                                <div class="col-4">Date</div>
                                <div class="col-4">Image</div>

                              </div>
                             </div>
                        </div>
                          
                      <div class="form-group">
                           <div class="col-12">

                            <div  class="row" >
                               <?php $__currentLoopData = $buys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <div class="col-4"> <?php echo e($buy->reference); ?>   </div>
                                    <div class="col-4"><?php echo e($buy->date); ?>         </div>
                                    <div class="col-4"><img src="<?php echo e(asset('images/')); ?>/<?php echo e($buy->image); ?>" width="200px" />      </div>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </div>

                          </div>    
                        </div>
               

                    </div>
                 
                    </div>
                </div>
         </div>

          <div class="col-md-12 grid-margin stretch-card">
                <div class="card ">
          
       
                  <div class="card-body">
                    <h4 class="card-title">Etat de command</h4>
                      <!--  <p class="card-description"> Basic form elements </p>-->
                        <div >
                               
                          <div class="form-group row">
                              <div class="col-12">
                                <div class="row">
                                  
                                    <div class="col-4">Etat</div>
                                    <div class="col-4">
                                        <?php if($order->status==0): ?>
                                            <h4><span class="badge badge-danger">En attente</span></h4>
                                        <?php endif; ?>
                                        <?php if($order->status==1): ?>
                                        <h4><span class="badge badge-success">valider</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-4"></div>

                                  </div>
                                 </div>
                            </div>
                        </div>
                 
                    </div>
                </div>
         </div>


         <div class="col-md-12 grid-margin stretch-card">
		   <?php if($order->status==0): ?>
                                   <button id='Envoyer'  class="btn btn-success mr-2 Envoyer">Valider</button>
                                        <?php endif; ?>
           
            <button id='Supprime'  class="btn btn-danger mr-2 Supprime">Supprime</button>
            
            <a class="btn btn-light" href="<?php echo e(url('order')); ?>">Annuler</a>
        </div>
    </div>  

    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsSup'); ?>

    <script>
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
    });


$(".Envoyer").click(function(event) {

 $(".Envoyer").hide()
     event.preventDefault();

   isBoss =  confirm("VOUS CONFIRMEZ LA COMMANDE !!!!");
    
    
              if(isBoss == true ){
            

                          $.ajax({
                          type:'POST',
                          headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
                          url:"<?php echo e(route('ajaxRequest.updateetat')); ?>",
                          data:{id:<?php echo e($order->id); ?> },
                          success:function(data){

                              if(data.success){

                                       alert('votre commande et valide ');
                                       location.reload();


                              }else{
                                      alert('erreur  ');
                              }
                       
                            
                          }
                        });


              }
         
        })

$("#Supprime").click(function(event) {

 $("#Supprime").hide()
     event.preventDefault();

  isBoss = confirm("VOUS VOULEZ CONFIRMEZ LA SUUPRIME CETTE COMMANDE!!!!");

      if(isBoss == true ){
    
                  $.ajax({
                  type:'POST',
                  headers: {'X-CSRF-TOKEN': $('meta[name="csrf_token"]').attr('content')},
                  url:"<?php echo e(route('ajaxRequest.deletedorder')); ?>",
                  data:{id:<?php echo e($order->id); ?> },
                  success:function(data){
          
                      if(data.success){

                               alert('votre commande Supprime ');
                               location.href = '<?php echo e(url('order')); ?>' ;

                      }else{
                              alert('erreur  ');
                      }
                    
                  }
                });

         }
  })               













    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\appca\resources\views/backend/order/edit.blade.php ENDPATH**/ ?>