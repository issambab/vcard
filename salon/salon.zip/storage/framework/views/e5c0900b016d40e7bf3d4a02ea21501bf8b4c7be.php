<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" >
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <title>Salon</title>
</head>
<body>
    <div class="container bg-white mt-5">
        <div class="row line-one" >
            <div class="col-md-4 justify-content-center d-flex align-items-center flex-column">
                <img src="<?php echo e(asset('img/logo.png')); ?>" class="w-50" alt="">
            </div>
            <div class="col-md-4 justify-content-center d-flex align-items-center flex-column">
                <img src="<?php echo e(asset('img/visiteurs.png')); ?>" class="w-25" alt="">
                <span class="text-nurom text-red font-size-32 mt-2">
                    25663
                </span>
                <span class="text-nurom font-size-24" style="line-height: 0.1;">
                    visiteurs   
                </span>
            </div>
            <div class="col-md-4 justify-content-center d-flex align-items-center flex-column">
                <img src="<?php echo e(asset('img/entretiens.png')); ?>" class="w-25" alt="">
                <span class="text-nurom text-red font-size-32 mt-2">
                    5663
                </span>
                <span class="text-nurom font-size-24" style="line-height: 0.1;">
                    entretiens   
                </span>
            </div>
        </div>
        <div class="row line-two" >
            <div class="col-md-4 justify-content-center d-flex align-items-center flex-column">
                <img src="<?php echo e(asset('img/cv.png')); ?>" class="w-25" alt="">
                <span class="text-nurom text-red font-size-32 mt-2">
                    25663
                </span>
                <span class="text-nurom font-size-24" style="line-height: 0.1;">
                    cv Collectés   
                </span>
            </div>
            <div class="col-md-4 justify-content-center d-flex align-items-center flex-column">
                <img src="<?php echo e(asset('img/pre.png')); ?>" class="w-25" alt="">
                <span class="text-nurom text-red font-size-32 mt-2">
                    25663
                </span>
                <span class="text-nurom font-size-24" style="line-height: 0.1;">
                    préselections   
                </span>
            </div>
            <div class="col-md-4 justify-content-center d-flex align-items-center flex-column">
                <img src="<?php echo e(asset('img/coaching.png')); ?>" class="w-25" alt="">
                <span class="text-nurom text-red font-size-32 mt-2">
                    25663
                </span>
                <span class="text-nurom font-size-24" style="line-height: 0.1;">
                    in coaching   
                </span>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" ></script>
</body>
</html><?php /**PATH /home/fairsjk/www/resources/views/front/home/index.blade.php ENDPATH**/ ?>