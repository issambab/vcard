
<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                    <div class="card-body"style="overflow: auto;" >
                        <h4 class="card-title">Liste Commande</h4>
                        <table class="table">
                          <thead>
                            <tr>
                              <th>N°</th>
                              <th>Nom & prenom</th>
                              <th>Télephone</th>
                              <th>Text /Zone(s) /Num(s) /N°sponso /Montant/statut</th>
                              
                            </tr>
                          </thead>
                      <tbody>
                      <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php if(isset($client->orders[0]->products )): ?> 
                        <tr>
                          <td><?php echo e($key + $clients->firstItem()); ?></td>
                          <td><?php echo e($client->name); ?></td>
                          <td><?php echo e($client->phone); ?></td>
                          <td>
                             
                            <?php $__currentLoopData = $client->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="border p-3 my-2">
                                <?php if(isset($order->products )): ?>   
                                <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h4 > <span class="badge badge-primary"><?php echo e($product->text_name); ?></span> <span  class="badge badge-info"> <?php echo e($product->zone); ?> / <?php echo e($product->number); ?> </span > <span class="badge badge-success"><?php echo e($product->nsponso); ?></span> <span class="h6"><?php echo e($zone[$product->zone][1]); ?> DT</span> 
                                        <?php if($order->status==0): ?>
                                        <span class="badge badge-danger">En attente</span>
                                        <?php endif; ?>
                                        <?php if($order->status==1): ?>
                                            <span class="badge badge-success">valider</span>
                                        <?php endif; ?>
                                        
                                    </h4>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php endif; ?>
                                <a href="#" class="btn btn-primary view my-2" data-toggle="modal" data-name="<?php echo e($client->name); ?>" data-target="#exampleModal" data-ref="<?php $__currentLoopData = $order->buys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($buy->reference); ?><?php if(count($order->buys)!=$key+1): ?>, <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>" data-date="<?php $__currentLoopData = $order->buys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($buy->date); ?><?php if(count($order->buys)!=$key+1): ?>,<?php endif; ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>" data-images="<?php $__currentLoopData = $order->buys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($buy->image); ?> <?php if(count($order->buys)!=$key+1): ?>,<?php endif; ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> ">
                            <i class="fa fa-eye"></i>
                          </a>
                          <br/>
                            </div>   
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                          </td>
                          
                         
                        </tr>
                         <?php endif; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      </tbody>
                    </table>
                    
                    showing <?php echo e(($clients->currentPage()-1)* $clients->perPage()+($clients->total() ? 1:0)); ?> to <?php echo e(($clients->currentPage()-1)*$clients->perPage()+count($clients)); ?>  of  <?php echo e($clients->total()); ?>  Results
                    <div class="d-flex justify-content-end mt-2">
                        <?php echo $clients->links(); ?>

                    </div>
                        
                    </div>
            </div> 
        </div> 
    </div>   
</div>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>     
<?php $__env->startSection('jsSup'); ?>
<script>

   
   
    $( document ).ready(function() {
        
        $('.view').click(function(){
            $('#exampleModal .modal-body').html('');
            
           ref= $(this).attr('data-ref');
           name= $(this).attr('data-name');
           date= $(this).attr('data-date');
           images= $(this).attr('data-images');
           $('#exampleModal .modal-title').html(name)
           var tabRef = ref.split(",");
            var tabDate = date.split(",");
            var tabImage = images.split(",");
            for (let i in tabRef) {
                $('#exampleModal .modal-body').append('<div class="text-center my-2"><b>Preuve de paiement</b></div>');
                $('#exampleModal .modal-body').append('<img class="w-100" src="images/'+tabImage[i].trim()+'">')
                $('#exampleModal .modal-body').append('<div><hr><b>Reference : </b>'+tabRef[i].trim()+'</div><hr>');
                $('#exampleModal .modal-body').append('<div><b>Date : </b>'+tabDate[i].trim()+'</div>');
            }   
        })
  
      
    })




</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\appca\resources\views/backend/client/index.blade.php ENDPATH**/ ?>