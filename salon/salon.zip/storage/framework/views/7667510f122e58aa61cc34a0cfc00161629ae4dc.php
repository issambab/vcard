
<?php if(Auth::user()->role == 0 ): ?>
<header class="justify-content-between d-flex my-2 py-2" style="border-bottom: 5px solid #766262;">
	 <div class="text-white"  ><h2><?php echo e(Auth::user()->name); ?> - <?php echo e(Auth::user()->boutique->gouv); ?></h2> </div>

	       <div class="" >
	        <span class="text-white" style="font-size: 1.25rem;"><?php echo e(Auth::user()->boutique->ref_boutique); ?> </span> 
	       
               <a  href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                                     	 <img src="<?php echo e(asset('images/user.png')); ?>" style="width: 30px;" class="mx-4" alt="">
                                                     </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                  <?php echo csrf_field(); ?>
                </form>


	        <img src="<?php echo e(asset('images/ooredoo.png')); ?>" style="width: 100px;" alt="">
	       </div>    
</header>
<?php else: ?>
<header class="justify-content-between d-flex my-2 py-2" style="border-bottom: 5px solid #766262;">
	 <div class="text-white"  ><h2><?php echo e(Auth::user()->name); ?></h2> </div>

	       <div class="" >
	        <span class="text-white" style="font-size: 1.25rem;"><?php echo e(Auth::user()->imprimeur->name); ?></span> 
	       
               <a  href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                                     	 <img src="<?php echo e(asset('images/user.png')); ?>" style="width: 30px;" class="mx-4" alt="">
                                                     </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                  <?php echo csrf_field(); ?>
                </form>


	        <img src="<?php echo e(asset('images/ooredoo.png')); ?>" style="width: 100px;" alt="">
	       </div>    
</header>
<?php endif; ?><?php /**PATH C:\wamp64\www\appcabonnement\resources\views/layouts/front/header.blade.php ENDPATH**/ ?>