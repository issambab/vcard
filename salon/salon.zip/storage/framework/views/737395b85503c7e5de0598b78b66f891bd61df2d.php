<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Site Officiel du CA | Club Africain</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" >
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="icon" href="<?php echo e(asset('cropped-favicon-192x192.png')); ?>" sizes="192x192" />
</head>
<body>
    <div class="container justify-content-center d-flex flex-column align-items-center">
        <div style="height: 30vh;" class="my-4">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" class="height-inherit"  >
        </div>
        <div style="height: 40vh;" class="text-center">
            <p class="text-white text-center"> l'opératice / opérateur </p>
            <img src="<?php echo e(asset('images/ooredoo.png')); ?>" alt="" class="my-2 " style="width: 150px;">
            <div class="d-flex flex-column align-items-center mt-2">
                <form action="<?php echo e(url('frontlogin')); ?>" method="POST" class="w-100">
                    <?php echo csrf_field(); ?>
                    <div>
                        <input type="email" name="email" id="" placeholder="Email">
                    </div>
                    <div>
                        <input type="password" name="password" id="" placeholder="Mot de passe" class="mt-4">
                    </div>
                        <?php if(Session::has('message')): ?>
                            <p class="alert alert-danger  mt-5"><?php echo e(Session::get('message')); ?></p>
                            <?php endif; ?>
                    <div >
                        <label for="rememberme" class="check mr-2">
                          
                            <input name="rememberme" type="checkbox" id="rememberme" >
                            <span class="text-white">Se souvenir de moi</span>
                            <span class="checkmark"></span>    
                        </label>
                        <button href="#" class="btn btn-red my-4" style="width: 150px;" type="submit">
                            Se connecter
                        </button>
                    </div>
                    
                </form>
                
            </div>
           
        </div>
		  <?php if(!Session::has('message')): ?>
        <div style="height: 16vh;" class="my-4">
            <img src="<?php echo e(asset('images/passport.png')); ?>" alt=""  class="height-inherit">
        </div>
		     <?php endif; ?>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" ></script>
</body>
</html><?php /**PATH C:\wamp64\www\appcabonnement\resources\views/front/home/index.blade.php ENDPATH**/ ?>