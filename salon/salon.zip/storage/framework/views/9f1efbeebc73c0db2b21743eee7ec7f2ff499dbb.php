
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>  <?php if(Auth::check()): ?> <?php echo e(Auth::user()->name); ?> <?php else: ?> user <?php endif; ?> </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" >
    <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
  />
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <style>
        g:hover .cls-1{
            fill:white;
            
        }
        g{
            cursor: pointer;
        }
    .popup {
        width: 230px;
        height: 180px;
        position: absolute;
        z-index: 3;
        background: white;
        border: 2px solid red;
        border-radius: 25px;
        top: 36%;
       }
   .mask {
    width: 100%;
    height: 100%;
    position: absolute;
    background-color: rgba(128, 128, 128, 0.377);
    z-index: 2;
       }  
       .fermer{
        float: right;
        margin: -21px -20px 0 0;
        cursor: pointer;
       }
       .A1CAR {    
            text-align: center;
            width: 200px;
            color: white;
       }
       .A1CAR2{
          width: 100%;
          text-align: center;
          color: white;
       }
       .error {
    background-color: #fce4e4;
    border: 1px solid #cc0033;
    outline: none;
} 
        </style>
</head>
<body class="d-flex justify-content-center">

    <div class="container-mobile my-md-3 my-0 d-flex justify-content-center align-items-center">
     <!--start header-->
     <header>
               <img src="<?php echo e(asset('img/menu.png')); ?>" alt="" class="menu">
               <img src="<?php echo e(asset('img/logo-ca.png')); ?>" alt="" class="logo">
               <ul class="nav-menu mt-3 text-white" style="display: none;">
                   <li>link1</li>
                   <li>link2</li>
                   <li>link3</li>
               </ul>
            </header>
        <!--end header-->
    <section class="section12 d-flex flex-column align-items-center mt-3" >
    
    <img src="<?php echo e(asset('img/forme.png')); ?>"  style="width: 100px;" class=" animate__animated animate__zoomIn mt-3" />
    <p class="text-gray-ca text-gothamrounded mt-3">
    <?php if(Auth::check()): ?> <?php echo e(Auth::user()->email); ?> <?php else: ?> user <?php endif; ?>   
    </p >
    <h4 class="width-p text-ooredooarabic text-ca  font-weight-bold mt-3">
    ﺍﻟﺒﻼﻳﺺ ﺇﻟﻲ ﻣﺮﻳﺰﺭﻓﻴﻬﻢ
    </h4>
    <div class="w-100" style="height: 239px;overflow-y: scroll;">   
    
    
    <div class="place d-flex mb-2" >
            <div class="place-b1" >
                <span class=" text-gothamrounded fs-18 text-white" style="vertical-align: -webkit-baseline-middle;">N° 103</span>
            </div>
            <div class="place-b2" > 
                <span class="text-gothamrounded fs-18 text-gray-ca" style="vertical-align: -webkit-baseline-middle;">Prix : 300 dt</span>
                <span class="float-right mr-2 badge badge-warning mt-2">en cours</span>
            </div>
        </div>
        <div class="place d-flex mb-2" >
            <div class="place-b1" >
                <span class=" text-gothamrounded fs-18 text-white mt-2s" style="vertical-align: -webkit-baseline-middle;">N° 103</span>
            </div>
            <div class="place-b2" > 
                <span class="text-gothamrounded fs-18 text-gray-ca" style="vertical-align: -webkit-baseline-middle;">Prix : 300 dt</span>
                <span class="float-right mr-2 badge badge-danger mt-2">Annuler</span>
            </div>
        </div>
        <div class="place d-flex mb-2" >
            <div class="place-b1" >
                <span class=" text-gothamrounded fs-18 text-white mt-2" style="vertical-align: -webkit-baseline-middle;">N° 103</span>
            </div>
            <div class="place-b2" > 
                <span class="text-gothamrounded fs-18 text-gray-ca" style="vertical-align: -webkit-baseline-middle;">Prix : 300 dt</span>
                <span class="float-right mr-2 badge badge-success mt-2">Valider</span>
            </div>
        </div>

        <div class="place d-flex mb-2" >
            <div class="place-b1" >
                <span class=" text-gothamrounded fs-18 text-white mt-2" style="vertical-align: -webkit-baseline-middle;">N° 103</span>
            </div>
            <div class="place-b2" > 
                <span class="text-gothamrounded fs-18 text-gray-ca" style="vertical-align: -webkit-baseline-middle;">Prix : 300 dt</span>
                <span class="float-right mr-2 badge badge-success mt-2">Valider</span>
            </div>
        </div>
        <div class="place d-flex mb-2" >
            <div class="place-b1" >
                <span class=" text-gothamrounded fs-18 text-white mt-2" style="vertical-align: -webkit-baseline-middle;">N° 103</span>
            </div>
            <div class="place-b2" > 
                <span class="text-gothamrounded fs-18 text-gray-ca" style="vertical-align: -webkit-baseline-middle;">Prix : 300 dt</span>
                <span class="float-right mr-2 badge badge-success mt-2">Valider</span>
            </div>
        </div>
        <div class="place d-flex mb-2" >
            <div class="place-b1" >
                <span class=" text-gothamrounded fs-18 text-white mt-2" style="vertical-align: -webkit-baseline-middle;">N° 103</span>
            </div>
            <div class="place-b2" > 
                <span class="text-gothamrounded fs-18 text-gray-ca" style="vertical-align: -webkit-baseline-middle;">Prix : 300 dt</span>
                <span class="float-right mr-2 badge badge-success mt-2">Valider</span>
            </div>
        </div>
        <div class="place d-flex mb-2" >
            <div class="place-b1" >
                <span class=" text-gothamrounded fs-18 text-white mt-2" style="vertical-align: -webkit-baseline-middle;">N° 103</span>
            </div>
            <div class="place-b2" > 
                <span class="text-gothamrounded fs-18 text-gray-ca" style="vertical-align: -webkit-baseline-middle;">Prix : 300 dt</span>
                <span class="float-right mr-2 badge badge-success mt-2">Valider</span>
            </div>
        </div>
     </div>   
        <div class="text-center">
    <a class="btn btn-ca text-ooredooarabic px-4 pt-3 fs-18 text-white mt-2" type="submit">ﻧﺮﺟﻊ</a>
   </div> 
</section>
</div> 
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" ></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" ></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" ></script>   
<script>
    
    $( document ).ready(function() {
    $("header").css('background-position', 'right 0 top -286px');
    $(".container-mobile").css('background-position', 'bottom -234px right');
    })
    </script>      
</body>
</html><?php /**PATH C:\wamp64\www\appca\resources\views/frontend/user.blade.php ENDPATH**/ ?>