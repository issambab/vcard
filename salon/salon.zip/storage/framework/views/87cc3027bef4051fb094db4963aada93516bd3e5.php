
<?php $__env->startSection('content'); ?>

 <div class="justify-content-center"  style="background: white;    padding: 25px;" >
	  	<table id="table_id" class="display">
		    <thead>
		       
								<th>NOM</th>
						
								<th>TELEPHONE</th>
								<th>CIN</th>
								<th>MAIL</th>
								<!--<th>GOUV</th>-->
								<th>CREER LE</th>
								<th>N° CARTE</th>
								<th>MAIL DOSSIER</th>
								<th>IMP CARTE</th>
								<th>MAIL CLIENT</th>
								<th>LIV CARTE</th>
		        </tr>
		    </thead>
		    <tbody>
		    	<?php $__currentLoopData = $listBotique; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			        <tr>
								
									<td><?php echo e($val->name); ?></td>
									<!--<td> <?php echo e(\Carbon\Carbon::parse($val->date_n)->diff(\Carbon\Carbon::now())->format('%y')); ?> </td>
									--><td><?php echo e($val->telephone); ?></td>
									<td><?php echo e($val->cin); ?></td>
									<td><?php echo e($val->email); ?></td>
									<!--<td><?php echo e($val->gouv); ?></td>-->
									<td><?php echo e(\Carbon\Carbon::parse($val->created_at)->format('m-d')); ?></td>
									<td><?php echo str_pad($val->id,5,0,STR_PAD_LEFT)  ?> </td>
									<td>
									<?php if($val->sms_creation == 1): ?>
										<img src="<?php echo e(asset('images/sms-active.png')); ?>" width="50%; ">
									<?php else: ?>
										<img src="<?php echo e(asset('images/sms.png')); ?>" width="50%; ">
									<?php endif; ?>
									

									</td>
									<td>
									<?php if($val->etat_imp == 1): ?>
									   <img src="<?php echo e(asset('images/imprim-active.png')); ?>" width="50%;" >
									<?php else: ?>
										<img src="<?php echo e(asset('images/imprim.png')); ?>" width="50%;" >
									<?php endif; ?>
									</td>
									<td class="sms_<?php echo e($val->id); ?>">
									
									<?php if($val->sms_liv == 1): ?>
								       <img src="<?php echo e(asset('images/sms-active.png')); ?>" width="50%;" >
									<?php elseif($val->etat_imp == 1): ?>
										<a href="#" onclick ="sms(<?php echo e($val->id); ?>)"   ><img src="<?php echo e(asset('images/sms.png')); ?>" width="50%;" ></a>
									<?php else: ?>	
										<img src="<?php echo e(asset('images/sms.png')); ?>" width="50%;" >
									<?php endif; ?>
									
									
									
									</td>
									<td class="liv_<?php echo e($val->id); ?>" >
									<?php if($val->etat_liv == 1): ?>
						
								        <img src="<?php echo e(asset('images/livresion-active.png')); ?>"  width="50%;" >
									<?php elseif($val->sms_liv == 1): ?>
										<a href="#" onclick ="liver(<?php echo e($val->id); ?>)"    ><img src="<?php echo e(asset('images/livresion.png')); ?>"  width="50%;" ></a>
									<?php else: ?>		
										<img src="<?php echo e(asset('images/livresion.png')); ?>"  width="50%;" >
									<?php endif; ?>
									
									
									</td>
			        </tr>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
		    </tbody>
		</table>
 </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("jsSup"); ?>
	
  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
<script>
	$(document).ready( function () {
		$('#table_id').DataTable({
            "order": [[ 5, "desc" ]],
			language: {
           url: "https://cdn.datatables.net/plug-ins/1.11.3/i18n/fr_fr.json"
    }
		})
  } );
  
  
  
  		function sms(id){
	  	  
		 var fd = new FormData() ;
	         fd.append('id',id ) ;
		 $.ajax({
              url: "<?php echo e(url('changesmsclient')); ?>" ,
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
               
                console.log(response);
                if(response) {
                	 $('.sms_'+id).html('<img src="<?php echo e(asset("images/sms-active.png")); ?>" width="50%; ">');
					   $('.liv_'+id).html('<a href="#" onclick ="liver('+id+')"><img src="<?php echo e(asset("images/livresion.png")); ?>"  width="50%;" ></a>');
                }else{
                		
                }
              },
           });
	}
	
	function liver(id){
	  	  
		 var fd = new FormData() ;
	         fd.append('id',id ) ;
		 $.ajax({
              url:  "<?php echo e(url('changelivclient')); ?>" ,
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
               
                console.log(response);
                if(response) {
                	 $('.liv_'+id).html('<img src="<?php echo e(asset("images/livresion-active.png")); ?>" width="50%; ">');
                }else{
                		
                }
              },
           });
	}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("cssSup"); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">
<style>
.sorting{
	font-size: 10px;
}
</style>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\appcabonnement\resources\views/front/home/listeabonne.blade.php ENDPATH**/ ?>