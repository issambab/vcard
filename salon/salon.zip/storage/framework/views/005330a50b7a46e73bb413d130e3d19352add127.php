<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Site Officiel du CA | Club Africain</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" >
	<link rel="icon" href="<?php echo e(asset('cropped-favicon-192x192.png')); ?>" sizes="192x192" />
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
        <?php echo $__env->yieldContent('cssSup'); ?>
</head>
<body>

<div class="loading">
<img src="<?php echo e(asset('images/loading.gif')); ?>"  class="img-loading" />
</div> 
     
     <div class="justify-content-center d-flex">

    	    <!-- start sidebar menu -->
             <?php echo $__env->make('layouts.front.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <!-- end sidebar menu -->

    
         <div class="container ">

           
             <!-- start sidebar menu -->
             <?php echo $__env->make('layouts.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
             <!-- end sidebar menu -->


            <!-- start page content -->
            <?php echo $__env->yieldContent('content'); ?>
            <!-- end page content -->

         </div>
   


     

    </div>
    
    <script src="https://code.jquery.com/jquery-3.1.1.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" ></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
      <?php echo $__env->yieldContent('jsSup'); ?>
</body>
</html><?php /**PATH /home/fairsjk/www/resources/views/layouts/front.blade.php ENDPATH**/ ?>