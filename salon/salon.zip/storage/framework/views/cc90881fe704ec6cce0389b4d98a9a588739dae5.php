<?php $__env->startSection('content'); ?>
 <div> </div>
 <div class="justify-content-center"  style="background: white;    padding: 25px;" >

	  	<table id="table_id" class="display">
		    <thead>
		        <tr>
								<th>NOM DE L'EVENEMENT</th>
								<th>CARTE IMP</th>
								<th>CARTE NON IMP</th>
								<th>TOTAL CARTE</th>
		        </tr>
		    </thead>
		    <tbody>

		    	 <?php $__currentLoopData = $listBotique; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				
			        <tr  >
								<td><?php echo e($val['name']); ?></td>
								
								<td><img src="<?php echo e(asset('images/imprim-active.png')); ?>" width="25%; "> <?php echo e($val['imp']); ?></td>
								<td><img src="<?php echo e(asset('images/imprim.png')); ?>" width="20%;" > <?php echo e($val['noimp']); ?></td>
								<td><?php echo e($val['total']); ?></td>
			        </tr>
	          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    	    
		    </tbody>
		</table>
		
 </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("jsSup"); ?>
	
  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
<script>
	$(document).ready( function () {
		$('#table_id').DataTable({
  
  language: {
url: "https://cdn.datatables.net/plug-ins/1.11.3/i18n/fr_fr.json"
}
})
	} );
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("cssSup"); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">
<style>
.sorting{
	font-size: 10px;
}
</style>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fairsjk/www/resources/views/front/home/listebyboutiqueimp.blade.php ENDPATH**/ ?>