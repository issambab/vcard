
<?php $__env->startSection('content'); ?>
        
         <div class="justify-content-center d-flex flex-column align-items-center" id="FormIn" >

	 
	   
               <p class="title" >Créer une Nouvelle CARTE </p>
                <form action=""  enctype="multipart/form-data" id="myform" >
				    <div >
                        <span class="star text-white">*</span>
						<select name="abon" id="abon" class="mt-2" >
							    <option value=""> Abonnement</option>
							    <option value="VIRAGE"> VIRAGE</option>
								<option value="PELOUSE">PELOUSE</option>
								<option value="ENCEINTE SUP">ENCEINTE SUP</option>
								<option value="ENCEINTE INF">ENCEINTE INF</option>
								<option value="TRIBUN">TRIBUNE</option>
						   </select>
                    </div>   
                    <div>
                      <span class="star text-white">*</span>  <input type="text" name="name" id="name" placeholder="Nom Prénom" class="mt-3">
                    </div>
                    <div>
                       <span class="star text-white">*</span> <input type="date" name="date" id="date" placeholder="Date de naissance" class="mt-3">
                    </div>
                    <div>
                        <span class="star text-white">*</span>  <input type="tel" name="phone" id="phone" placeholder="N° Mobile" class="mt-3">
                      </div>
                    <div>
                         <span class="star text-white" style="">*</span> <input type="text" name="cin" id="cin" placeholder="CIN" class="mt-3">
                    </div>
                    <div>
                        <span class="star text-white"style="opacity: 0;">*</span> <input type="email" name="email" id="email" placeholder="email" class="mt-3">
                   </div>
                   <div>
                    <span class="star text-white">*</span>
                       <select name="gouv" id="gouv" class="mt-3">
                           <option value="">Gouvernorat</option>
                                       <option value="Ariana">Ariana</option>
                                        <option value="Béja">Béja</option>
                                        <option value="Ben Arous">Ben Arous</option>
                                        <option value="Bizerte">Bizerte</option>
                                        <option value="Gabès">Gabès</option>
                                        <option value="Gafsa">Gafsa</option>
                                        <option value="Jendouba">Jendouba</option>
                                        <option value="Kairouan">Kairouan</option>
                                        <option value="Kasserine">Kasserine</option>
                                        <option value="Kébili">Kébili</option>
                                        <option value="Le Kef">Le Kef</option>
                                        <option value="Mahdia">Mahdia</option>
                                        <option value="La Manouba">La Manouba</option>
                                        <option value="Médenine">Médenine</option>
                                        <option value="Monastir">Monastir</option>
                                        <option value="Nabeul">Nabeul</option>
                                        <option value="Sfax">Sfax</option>
                                        <option value="Sidi Bouzid">Sidi Bouzid</option>
                                        <option value="Siliana">Siliana</option>
                                        <option value="Sousse">Sousse</option>
                                        <option value="Tataouine">Tataouine</option>
                                        <option value="Tozeur">Tozeur</option>
                                        <option value="Tunis">Tunis</option>
                                        <option value="Zaghouan">Zaghouan</option>
                       </select>

                      </div>
                   <div class="mt-3">
                        <span class="star text-white">*</span>
                       <!-- <input type="file" name="file_img" id="file-img" hidden="hidden">
                        <button type="button" class="file-img" id="custom-button-photo">Photo</button>-->
                        <input type="file" name="file_cin" id="file-cin" hidden="hidden">
                        <button type="button" class="file-cin" id="custom-button-cin">CIN</button>
						<input type="file" name="file_recu" id="file-recu" hidden="hidden">
                        <button type="button" class="file-recu"  id="custom-button-recu">Recu</button>
						
                   </div>  
             
                    <div class="text-center">
                        <button  class="btn btn-red my-4" style="width: 150px;" type="button" onclick="submitForm()">
                            Créer
                        </button>
                        <p class="title text-white " style="font-size: 12px;">
                           <span class="star" style="font-size: 12px;">*</span>  Champs Obligatoire
                        </p>
                    </div>
                </form>
            </div>
                
            <div class="justify-content-center d-flex flex-column align-items-center"  id="FormIn2" style="display:none!important;">
                	 <p class="title" id="titleVerif">Verification de la CARTE </p>
	                   <div class="carte justify-content-end d-flex flex-column pl-0 pr-5 " id="carteVerif" style="">
					   
					   	<div class="abonnemnt title" style="">
	                        <span id="abon_verif">VIRAGE</span>
	                    </div>
						
	                    <div class="title pl-3">
	                        <span id="title_verif">FOULENE BEN FALTENNE</span></br>
	                        N xxxxxx
	                        <hr style="border-top: 2px solid white;margin-top: 0;"> 
	                    </div>
	                    <div class=" pl-3">
	                        <b class="text-white">Date de naissaince : <span id="date_verif" >8-88-8888</span></b>
	                    </div>
	                    <div class=" pl-3">
	                        <b class="text-white">Téléphone : <span id="phone_verif" >22 850 555</span></b>
	                    </div>
	                    <div  class=" pl-3">
	                        <b class="text-white">Cin: <span id="cin_verif" >05555445</span></b>
	                    </div>
	                    <div  class=" pl-3">
	                        <b class="text-white">Mail : <span id="mail_verif" ></span></b>
	                    </div>
	                    <div  class="pl-3">
	                        <b class="text-white">Gouv : <span id="gouv_verif" >ariana</span></b>
	                    </div>
	                 
	                </div>
                <div class="mt-2">
                    <button  class="btn btn-white " style="width: 150px;" id="modif" type="button" onclick="modifForm()">
                        Modifier  
                    </button>
                    <button  class="btn btn-red " style="width: 150px;" id="supprim"  type="button" onclick="submitAbonnement()">
                        VALIDER
                    </button>
                </div> 
            
           </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("jsSup"); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>

 function submitForm(){
 
    $validation = true ; 


	if($("#name").val() == ""){ $("#name").addClass('error');  $validation = false ; }else{ $("#name").removeClass('error'); }
	if($("#phone").val() == ""){ $("#phone").addClass('error');  $validation = false ; }else{ $("#phone").removeClass('error'); }

	if($("#cin").val() == ""){ $("#cin").addClass('error');  $validation = false ; }else{ $("#cin").removeClass('error');  }
	/*if($("#email").val() == ""){ $("#email").addClass('error');  $validation = false ; }else{ $("#email").removeClass('error');  }*/
	
	if($("#abon").val() == ""){ $("#abon").addClass('error');  $validation = false ; }else{ $("#abon").removeClass('error');  }

	if($("#gouv").val() == ""){ $("#gouv").addClass('error');  $validation = false ; }else{ $("#gouv").removeClass('error'); }
	if($("#Abonnement").val() == ""){ $("#Abonnement").addClass('error');  $validation = false ; }else{ $("#Abonnement").removeClass('error'); }
	if($("#date").val() == ""){ $("#date").addClass('error');  $validation = false ; }else{ $("#date").removeClass('error'); }
	/*if($('#file-img')[0].files.length === 0){ $(".file-img").addClass('error');  $validation = false ; }else{ $(".file-img").removeClass('error'); }*/

	if($('#file-cin')[0].files.length === 0){ $(".file-cin").addClass('error');  $validation = false ; }else{ $(".file-cin").removeClass('error'); }

	if($('#file-recu')[0].files.length === 0){ $(".file-recu").addClass('error');  $validation = false ; }else{ $(".file-recu").removeClass('error'); }

	if($validation){
			var mo = 2097152;

			var fd = new FormData();
			/*var filesimag = $('#file-img')[0].files ;*/
			var filescin =  $('#file-cin')[0].files ;
			var filesrecu =  $('#file-recu')[0].files ;
		
          
		  if(filescin[0].size > mo){

				   $(".file-cin").addClass('error'); 
				   alert("max upload image cin  2mo") ;

			  }else if(filesrecu[0].size > mo){

			    $(".file-recu").addClass('error'); 
			    alert("max upload image recu  2mo") ;

			/*  }else if(!isFileImage(filesimag[0])){

			         $(".file-img").addClass('error'); 
			  		alert("extention image no valide") ;*/

			  }else if(!isFileImage(filescin[0])){

			        $(".file-cin").addClass('error');     
			  		alert("extention cin no valide") ;
			  	
			  }else if(!isFileImage(filesrecu[0])){
			        $(".file-recu").addClass('error'); 
			  		alert("extention recu no valide") ;
			  	
			  }else{
				  
				  	var fds = new FormData();
					fds.append('cin',$("#cin").val())
				  
			$.ajax({
              url: "<?php echo e(url('cin')); ?>",
              type: 'post',
              data: fds,
              contentType: false,
              processData: false,
              success: function(response){
               
                console.log(response);
				 if(response.errors) {
				alert(response.errors);
				 }else if(response==true) {
					
					if($("#abon").val() == "VIRAGE" ){
					    $(".abonnemnt").attr("style", "background:#e40615!important");
					}else if($("#abon").val() == "PELOUSE" ){
						$(".abonnemnt").attr("style", "background:#001a9d!important");
					}else if($("#abon").val() == "ENCEINTE SUP" ){
						$(".abonnemnt").attr("style", "background:#a9a9a9!important");
					}else if($("#abon").val() == "ENCEINTE INF" ){
					    $(".abonnemnt").attr("style", "background:#3c3c3c!important");
					}else if($("#abon").val() == "TRIBUN" ){
						$(".abonnemnt").attr("style", "background:#701342!important");
						
					}	
                	
				   $("#title_verif").html($("#name").val() )     ;
				   $("#gouv_verif").html($("#gouv  option:selected").text())  ;

				   $("#mail_verif").html($("#email").val() ) ;
				   $("#cin_verif").html($("#cin").val() ) ;
				   $("#phone_verif").html($("#phone").val() ) ;
				   $("#date_verif").html($("#date").val());

                  $("#abon_verif").html($("#abon").val());

			       $("#FormIn").fadeOut('slow',function(){ $("#FormIn").attr("style","display:none!important"); } );
			  	   $("#FormIn2").fadeIn(3000);
					
					
					
                }else{
                		alert('cin déja utilisée');
						$("#cin").addClass('error');
                			
                }



              },
           });
			  	    	
			       
				
			  	      
			  }

	    }

};

     function modifForm(){

       $("#FormIn2").fadeOut('slow', function(){ $("#FormIn2").attr("style","display:none!important");
                                                 $("#FormIn").fadeIn();
                                             });
     }

function isFileImage(file) {
   
     var t = file.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "pdf") { 
        return false;
    }else{    	return true;   }
}

function submitAbonnement(){

	var fd = new FormData();
/*	var filesimag = $('#file-img')[0].files ;*/
	var filescin =  $('#file-cin')[0].files ;
	var filesrecu =  $('#file-recu')[0].files ;

/*	fd.append('filesimag',filesimag[0]);*/
	fd.append('filescin',filescin[0]);
	fd.append('filesrecu',filesrecu[0]);
    fd.append('gouv',$("#gouv  option:selected").val());

	fd.append('name',$("#name").val() ) 
	fd.append('email',$("#email").val() ) 
	fd.append('cin',$("#cin").val() ) 
	fd.append('phone',$("#phone").val() ) 
	fd.append('date',$("#date").val())
	fd.append('abon',$("#abon").val())
	$(".loading").show();
	$("#supprim").hide();
	$("#loading").hide();


           $.ajax({
              url:  "<?php echo e(url('submitabon')); ?>", 
              type: 'post',
              data: fd,
              contentType: false,
              processData: false,
              success: function(response){
               
                console.log(response);
                if(response) {
                	alert('votre abonnement a ete bien enregistré')
                	location.reload()
                }else{
                		alert('erreur leur de l enregistré')
                			location.reload()
                }



              },
           });
}

</script>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection("cssSup"); ?>
<style>
.error{
border: 5px solid red !important; 
}
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\appcabonnement\resources\views/front/home/creation.blade.php ENDPATH**/ ?>