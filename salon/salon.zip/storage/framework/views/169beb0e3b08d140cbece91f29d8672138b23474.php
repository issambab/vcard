<!--<html>
    <head>

    </head>
    <body>
    <img src="<?php echo e(asset('assets/images/maillot.jpg')); ?>" alt="" style="width:90%;text-align: center;">
    </body>
</html>
--><!DOCTYPE >
<html >
<head>
	<!--[if gte mso 9]>
		<xml>
			<o:OfficeDocumentSettings>
			  <o:AllowPNG/>
			  <o:PixelsPerInch>96</o:PixelsPerInch>
			</o:OfficeDocumentSettings>
		</xml>
	<![endif]-->
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="format-detection" content="date=no" />
	<meta name="format-detection" content="address=no" />
	<meta name="format-detection" content="telephone=no" />
    <link href="https://fonts.googleapis.com/css?family=Gudea:400,400i,700|Hind+Guntur:400,700" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@200&display=swap" rel="stylesheet">
	<title>Email Template</title>
	

	<style type="text/css" media="screen">
		[style*="HG"] { 
			font-family: 'Hind Guntur', Arial, sans-serif !important
		}
		[style*="Gudea"] { 
			font-family: 'Gudea', Arial, sans-serif !important
		}
		/* Linked Styles */
		body { padding:0 !important; margin:0 !important; display:block !important; min-width:100% !important; width:100% !important; background:#ffffff; -webkit-text-size-adjust:none; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px }
		a { color:#ed5258; text-decoration:none }
		p { padding:0 !important; margin:0 !important } 
		img { -ms-interpolation-mode: bicubic; /* Allow smoother rendering of resized image in Internet Explorer */ }
		table { mso-cellspacing: 0px; mso-padding-alt: 0px 0px 0px 0px; }

		/* Mobile styles */
		@media  only screen and (max-device-width: 480px), only screen and (max-width: 480px) {
			table[class='mobile-shell'] { width: 100% !important; min-width: 100% !important; }
			table[class='center'] { margin: 0 auto !important; }
			table[class='left'] { margin-right: auto !important; }
			
			td[class='td'] { width: 100% !important; min-width: 100% !important; }
			td[class='auto'] { width: 100% !important; min-width: auto !important; }

			div[class='mobile-br-3'] { height: 4px !important; background: #ffffff !important; display: block !important; }
			div[class='mobile-br-4'] { height: 4px !important; background: #2d2d31 !important; display: block !important; }
			div[class='mobile-br-5'] { height: 5px !important; }
			div[class='mobile-br-10'] { height: 10px !important; }
			div[class='mobile-br-15'] { height: 15px !important; }
			div[class='mobile-br-25'] { height: 25px !important; }

			th[class='m-td'],
			td[class='m-td'],
			div[class='hide-for-mobile'], 
			span[class='hide-for-mobile'] { display: none !important; width: 0 !important; height: 0 !important; font-size: 0 !important; line-height: 0 !important; min-height: 0 !important; }

			span[class='mobile-block'] { display: block !important; }
			div[class='img-m-center'] { text-align: center !important; }
			div[class='img-m-left'] { text-align: left !important; }

			div[class='fluid-img'] img,
			td[class='fluid-img'] img { width: 100% !important; max-width: 100% !important; height: auto !important; }

			div[class='h1'],
			div[class='slogan'],
			div[class='h1-left'],
			div[class='h1-white'],
			div[class='h1-white-r'],
			div[class='h1-secondary'],
			div[class='text-footer'],
			div[class='text-footer-r'],
			div[class='text-footer-r2'],
			div[class='h2-white-m-center'],
			div[class='h1-white-secondary-r'] { text-align: center !important; }

			th[class='column'],
			th[class='column-top'],
			th[class='column-dir-t'],
			th[class='column-bottom'],
			th[class='column-dir'] { float: left !important; width: 100% !important; display: block !important; }
			div[class='text-top'] { text-align: center !important; }
			th[class='column-top-black'] { float: left !important; width: 100% !important; display: block !important; background: #2d2d31 !important; }

			td[class='item'] { width: 150px !important; }

			td[class='content-spacing'] { width: 15px !important; }
			td[class='content-spacing-pink'] { width: 15px !important; background: #ed5258 !important; }
		}
	</style>
</head>
<body class="body" style="padding:0 !important; margin:0 !important; display:block !important; min-width:100% !important; width:100% !important; background:#ffffff; -webkit-text-size-adjust:none; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">
	<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
		<tr>
			<td align="center" valign="top">
				<!-- Header -->
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td>
							<!-- Top Bar -->
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td class="content-spacing" style="font-size:0pt; line-height:0pt; text-align:left" bgcolor="#ed5258">&nbsp;</td>
									<td align="center" width="650" class="td" style="width:650px; min-width:650px; font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; Margin:0">
										<table width="650" border="0" cellspacing="0" cellpadding="0" class="mobile-shell" bgcolor="#ed5258">
											<tr>
												<td class="td" style="width:650px; min-width:650px; font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; Margin:0">
													<table width="100%" border="0" cellspacing="0" cellpadding="0">
														<tr>
															<th class="column" style="font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; Margin:0">
																<table width="100%" border="0" cellspacing="0" cellpadding="0">
																	<tr>
																		<td class="img" style="font-size:0pt; line-height:0pt; text-align:left">
																			<table width="100%" border="0" cellspacing="0" cellpadding="0" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px"><tr><td height="25" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">&nbsp;</td></tr></table>

																			<table class="center" border="0" cellspacing="0" cellpadding="0">
																				<tr>
																					<td class="text-top2" style="color:#ffffff; font-family:Arial,sans-serif, 'HG'; font-size:11px; line-height:16px; text-align:left; text-transform:uppercase; font-weight:bold"><a href="#" target="_blank" class="link-white-u" style="color:#ffffff; text-decoration:underline"><span class="link-white-u" style="color:#ffffff; text-decoration:underline">View Online</span></a></td>
																					<td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="20"></td>
																					<td class="text-top2" style="color:#ffffff; font-family:Arial,sans-serif, 'HG'; font-size:11px; line-height:16px; text-align:left; text-transform:uppercase; font-weight:bold"><a href="#" target="_blank" class="link-white-u" style="color:#ffffff; text-decoration:underline"><span class="link-white-u" style="color:#ffffff; text-decoration:underline">FORWARD</span></a></td>
																				</tr>
																			</table>
																			<table width="100%" border="0" cellspacing="0" cellpadding="0" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px"><tr><td height="25" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">&nbsp;</td></tr></table>

																		</td>
																	</tr>
																</table>
															</th>
															<th class="column" style="font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; Margin:0" width="240" bgcolor="#f6f6f6">
																<table width="100%" border="0" cellspacing="0" cellpadding="0">
																	<tr>
																		<td align="right">
																			<table width="100%" border="0" cellspacing="0" cellpadding="0" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px"><tr><td height="25" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">&nbsp;</td></tr></table>

																			<table class="center" border="0" cellspacing="0" cellpadding="0">
																				<tr>
																					<td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="40"><a href="#" target="_blank"><img src="images/ico2_facebook.jpg" border="0" width="14" height="13" alt="" /></a></td>
																					<td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="40"><a href="#" target="_blank"><img src="images/ico2_twitter.jpg" border="0" width="14" height="13" alt="" /></a></td>
																					<td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="40"><a href="#" target="_blank"><img src="images/ico2_gplus.jpg" border="0" width="14" height="13" alt="" /></a></td>
																					<td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="40"><a href="#" target="_blank"><img src="images/ico2_pinterest.jpg" border="0" width="14" height="13" alt="" /></a></td>
																					<td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="14"><a href="#" target="_blank"><img src="images/ico2_instagram.jpg" border="0" width="14" height="13" alt="" /></a></td>
																				</tr>
																			</table>
																			<table width="100%" border="0" cellspacing="0" cellpadding="0" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px"><tr><td height="25" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">&nbsp;</td></tr></table>

																		</td>
																	</tr>
																</table>
															</th>
														</tr>
													</table>
												</td>
											</tr>
										</table>
									</td>
									<td class="content-spacing-pink" style="font-size:0pt; line-height:0pt; text-align:left" bgcolor="#f6f6f6">&nbsp;</td>
								</tr>
							</table>
							<!-- END Top Bar -->
							
				<!-- Section 2 -->
				<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#2d2d31">
					<tr>
						<td class="content-spacing" style="font-size:0pt; line-height:0pt; text-align:left" width="1">&nbsp;</td>
						<td align="center">
							<table width="650" border="0" cellspacing="0" cellpadding="0" class="mobile-shell">
								<tr>
									<td class="td" style="width:650px; min-width:650px; font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; Margin:0">
										<table width="100%" border="0" cellspacing="0" cellpadding="0" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px"><tr><td height="42" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">&nbsp;</td></tr></table>

										<div class="h2-white-center" style="color:#f6f6f6; font-family:Arial,sans-serif, 'HG'; font-size:26px; line-height:30px; text-align:center; font-weight:bold">Huge Sale Coming on June 24th</div>
										<table width="100%" border="0" cellspacing="0" cellpadding="0" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px"><tr><td height="22" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">&nbsp;</td></tr></table>

										<div class="text-light-grey" style="color:#b6b6b6; font-family:Arial,sans-serif, 'Gudea'; font-size:18px; line-height:28px; text-align:right;font-family: 'Tajawal', sans-serif !important;">السلام جمعية، برافو عليك ، هاو نومرو سبنسصورينغ متاعك بش تشوف بيه اسمك على المريول :0000000000</div>
										<!-- Button -->
										<table width="100%" border="0" cellspacing="0" cellpadding="0" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px"><tr><td height="25" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">&nbsp;</td></tr></table>

										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr>
												<td align="center">
													<table class="center" border="0" cellspacing="0" cellpadding="0" bgcolor="#ed5258">
														<tr>
															<td class="img" style="font-size:0pt; line-height:0pt; text-align:left" height="34" width="12"></td>
															<td>
																<table width="100%" border="0" cellspacing="0" cellpadding="0" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px"><tr><td height="6" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">&nbsp;</td></tr></table>

																<div class="button1" style="color:#ffffff; font-family:Arial,sans-serif; font-size:13px; line-height:20px; text-align:center; text-transform:uppercase; font-weight:bold"><a href="#" target="_blank" class="link-white" style="color:#ffffff; text-decoration:none"><span class="link-white" style="color:#ffffff; text-decoration:none">FIND OUT MORE</span></a></div>
																<table width="100%" border="0" cellspacing="0" cellpadding="0" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px"><tr><td height="6" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">&nbsp;</td></tr></table>

															</td>
															<td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="12"></td>
														</tr>
													</table>
												</td>
											</tr>
										</table>
										<!-- END Button -->
										<table width="100%" border="0" cellspacing="0" cellpadding="0" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px"><tr><td height="42" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">&nbsp;</td></tr></table>

									</td>
								</tr>
							</table>
						</td>
						<td class="content-spacing" style="font-size:0pt; line-height:0pt; text-align:left" width="1">&nbsp;</td>
					</tr>
				</table>
				<!-- END Section 2 -->
				<!-- Section 1 -->
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td class="content-spacing" style="font-size:0pt; line-height:0pt; text-align:left" bgcolor="#ed5258">&nbsp;</td>
						<td align="center" width="650" class="td" style="width:650px; min-width:650px; font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; Margin:0">
							<table width="650" border="0" cellspacing="0" cellpadding="0" class="mobile-shell" bgcolor="#ed5258">
								<tr>
									<td class="td" style="width:650px; min-width:650px; font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; Margin:0">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tr>
												<th class="column" style="font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; Margin:0">
													<table width="100%" border="0" cellspacing="0" cellpadding="0">
														<tr>
															<td class="fluid-img" style="font-size:0pt; line-height:0pt; text-align:left"><img src="images/image1.jpg" border="0" width="409" height="364" alt="" /></td>
														</tr>
													</table>
												</th>
												<th class="column" style="font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; Margin:0" width="240" bgcolor="#f6f6f6">
													<table width="100%" border="0" cellspacing="0" cellpadding="0">
														<tr>
															<td class="content-spacing" style="font-size:0pt; line-height:0pt; text-align:left" width="1"></td>
															<td align="right">
																<table width="100%" border="0" cellspacing="0" cellpadding="0" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px"><tr><td height="25" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">&nbsp;</td></tr></table>

																<div class="h1" style="color:#2d2d31; font-family:impact, 'AvenirNextCondensed-Bold', Arial,sans-serif; font-size:50px; line-height:64px; text-align:right; text-transform:uppercase">#شعبها<br />#سبنصورها<br />#الافريقي<br />#تعيش</div>
																<table width="100%" border="0" cellspacing="0" cellpadding="0" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px"><tr><td height="25" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">&nbsp;</td></tr></table>

															</td>
															<td class="content-spacing" style="font-size:0pt; line-height:0pt; text-align:left" width="1"></td>
														</tr>
													</table>
												</th>
											</tr>
										</table>
									</td>
								</tr>
							</table>
						</td>
						<td class="content-spacing-pink" style="font-size:0pt; line-height:0pt; text-align:left" bgcolor="#f6f6f6">&nbsp;</td>
					</tr>
				</table>
				<!-- END Section 1 -->
				
				<!-- Header -->
                <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#2d2d31">
								<tr>
									<td align="center">
										<table width="100%" border="0" cellspacing="0" cellpadding="0" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px"><tr><td height="30" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">&nbsp;</td></tr></table>

										<table width="650" border="0" cellspacing="0" cellpadding="0" class="mobile-shell">
											<tr>
												<td class="td" style="width:650px; min-width:650px; font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; Margin:0">
													<!-- Header -->
													<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#2d2d31">
														<tr>
															<th class="column" style="font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; Margin:0">
																<table width="100%" border="0" cellspacing="0" cellpadding="0">
																	<tr>
																		<td class="img" style="font-size:0pt; line-height:0pt; text-align:left">
																			<div class="img-m-center" style="font-size:0pt; line-height:0pt"><a href="#" target="_blank"><img src="images/logo_free.jpg" border="0" width="166" height="43" alt="" /></a></div>
																			<div style="font-size:0pt; line-height:0pt;" class="mobile-br-15"></div>

																		</td>
																	</tr>
																</table>
															</th>
															<th class="column" style="font-size:0pt; line-height:0pt; padding:0; margin:0; font-weight:normal; Margin:0" width="240">
																<table width="100%" border="0" cellspacing="0" cellpadding="0">
																	<tr>
																		<td align="right">
																			<table class="center" border="0" cellspacing="0" cellpadding="0">
																				<tr>
																					<td class="img" style="font-size:0pt; line-height:0pt; text-align:left" width="22"><img src="images/ico_link.jpg" border="0" width="13" height="13" alt="" /></td>
																					<td class="text-top2" style="color:#ffffff; font-family:Arial,sans-serif, 'HG'; font-size:11px; line-height:16px; text-align:left; text-transform:uppercase; font-weight:bold"><a href="#" target="_blank" class="link-white-u" style="color:#ffffff; text-decoration:underline"><span class="link-white-u" style="color:#ffffff; text-decoration:underline">GO TO THE STORE</span></a></td>
																				</tr>
																			</table>
																		</td>
																	</tr>
																</table>
															</th>
														</tr>
													</table>
													<!-- END Header -->
												</td>
											</tr>
										</table>
										<table width="100%" border="0" cellspacing="0" cellpadding="0" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px"><tr><td height="30" class="spacer" style="font-size:0pt; line-height:0pt; text-align:center; width:100%; min-width:100%; mso-cellspacing:0px; mso-padding-alt:0px 0px 0px 0px">&nbsp;</td></tr></table>

									</td>
								</tr>
							</table>
							<!-- END Header -->
						</td>
					</tr>
				</table>
				<!-- END Header -->
			
				
				<table height="100">
                <tr>
                    <td style="olor: #f6f6f6;
                    font-family: Arial,sans-serif, 'HG';
                    font-size: 12px;
                    line-height: 30px;
                    text-align: center;
                    font-weight: bold;">
                        copyright © 2021 Atelier216. All rights reserved.
                    </td>
                </tr>

                </table>
				
					
			

			
			</td>
		</tr>
	</table>
</body>
</html>

<?php /**PATH C:\wamp64\www\appca\resources\views/welcome.blade.php ENDPATH**/ ?>