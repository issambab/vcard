 <?php if(Auth::user()->role == 0 ): ?>
 <div class="sidebar d-none d-md-block  pl-3" style="padding-top: 10rem;">
            <a href="<?php echo e(url('creation')); ?>" class="btn  <?php echo e(request()->route()->uri=='creation'  ?'btn-red':'btn-white'); ?>  my-4" style="width: 150px;" type="submit">
                Créer une Carte 
            </a>
          
            <a href="<?php echo e(url('listabonne')); ?>/<?php echo e(Auth::user()->boutique->id); ?>" class="btn <?php echo e(request()->route()->uri=='listabonne/{id}'  ?'btn-red':'btn-white'); ?>  my-0" style="width: 150px;"  type="submit" >
                Liste Des cartes
            </a>
        
  </div>
<?php else: ?> 

 <div class="sidebar d-none d-md-block  pl-3" style="padding-top: 1.2rem; background-color: whitesmoke;">
          <div class="passport" style="text-align: center"  >
              <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" style="width: 100px;" class="height-inherit">
          </div>
            <a href="<?php echo e(url('imprimant')); ?>" class=" btn <?php echo e(request()->route()->uri=='imprimant'  ?'btn-red-submit':'btn-white'); ?>  mt-4" style="width: 170px;" type="submit">
               Liste des Evenement
            </a>

            <a href="<?php echo e(url('carteimprimein')); ?>" class="btn <?php echo e(request()->route()->uri=='carteimprimein'  ?'btn-red-submit':'btn-white'); ?>  my-3" style="width: 170px;"  type="submit" >
              Liste a imprimer
            </a>
          
            <a href="<?php echo e(url('carteimprime')); ?>" class=" btn <?php echo e(request()->route()->uri=='carteimprime'  ?'btn-red-submit':'btn-white'); ?>  my-0" style="width: 170px;"  type="submit" >
              Liste Des cartes
            </a>
        
       

            
 </div>       
<?php endif; ?>       

<?php /**PATH /home/fairsjk/www/resources/views/layouts/front/sidebar.blade.php ENDPATH**/ ?>