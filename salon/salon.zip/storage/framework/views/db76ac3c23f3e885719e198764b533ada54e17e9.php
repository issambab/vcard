
<?php $__env->startSection('content'); ?>

 <div class="justify-content-center"  style="background: white;    padding: 25px;" >
	  	<table id="table_id" class="display">
		    <thead>
		        <tr style="text-align: center;">
				<th>NOM BOUTIQUE</th>
				<th>CREER LE</th>
				<th>N° CARTE</th>
				<th>ID NFC</th>
				<th>GOUV</th>
				<th>COPIE DONNEES CARTE</th>
				<th>COPIE ID NFC </th>
				<th>IMP CARTE </th>
		        </tr>
		    </thead>
		    <tbody>

		    	 <?php $__currentLoopData = $listBotique; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			        <tr style="text-align: center;">        
	        	        <td><?php echo e($val->name); ?></td>
						<td><?php echo e(\Carbon\Carbon::parse($val->created_at)->format('Y-m-d')); ?>  </td>
						<td><?php echo str_pad($val->id,5,0,STR_PAD_LEFT)  ?> </td>
						<td><?php echo e($val->id); ?></td>
						<td><?php echo e($val->gouv); ?></td>
						<td><a href=""><img src="<?php echo e(asset('images/copie.png')); ?>" width="15%; "> </a></td>
						<td><a href=""><img src="<?php echo e(asset('images/nfc.png')); ?>" width="30%;" > </a></td>
						<td><a href=""><img src="<?php echo e(asset('images/imprim-active.png')); ?>" width="25%; "></a></td>
			        </tr>
	          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    	    
		    </tbody>
		</table>
		
 </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("jsSup"); ?>
	
  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
<script>
	$(document).ready( function () {
	    $('#table_id').DataTable();
	} );
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("cssSup"); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">
<style>
.sorting{
	font-size: 10px;
}
</style>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\appcabonnement\resources\views/front/home/listebycarteimp.blade.php ENDPATH**/ ?>