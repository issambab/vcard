
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin ">
        <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Zones</h4>
                    <?php echo $select; ?>

                 </div>
        </div>         
        
        </div>             
    </div>  
</div>                    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\appca\resources\views/backend/zones.blade.php ENDPATH**/ ?>